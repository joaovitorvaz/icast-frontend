COMO RODAR O PROJETO BAIXADO
Instalar todas as dependencias indicada pelo package.json
### npm install

Rodar o projeto usando o nodemon 
### nodemon app.js


SEQUENCIA PARA CRIAR O PROJETO
Criar o arquivo package
### npm init

Gerencia as requisições, rotas e URLs, entre outra funcionalidades
### npm install express

Rodar o projeto 
### node app.js

Acessar o projeto no navegador
### http://localhost:8080

Instalar o módulo para reiniciar o servidor sempre que houver alteração no código fonte, g significa globalmente
Executar no prompt de comando somente quando nunca utilizou o Nodemon
### npm install -g nodemon
Instalar o Nodemon no projeto
### npm install --save-dev nodemon

Rodar o projeto com o Nodemon
### nodemon app.js

Multer é um middleware node.js para manipulação multipart/form-data, usado para o upload de arquivos. 
### npm install --save multer

Permitir acesso a API
### npm install --save cors
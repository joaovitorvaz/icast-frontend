COMO RODAR O PROJETO BAIXADO
Instalar todas as dependencias indicada pelo package.json
### npm install

Rodar o projeto React 
### npm start


SEQUENCIA PARA CRIAR O PROJETO
Criar o projeto React - https://pt-br.reactjs.org/docs/create-a-new-react-app.html
### npx create-react-app my-app

Acessar o diretório do projeto
### cd my-app

Rodar o projeto React 
### npm start

Realizar chamada para API
### npm install --save axios